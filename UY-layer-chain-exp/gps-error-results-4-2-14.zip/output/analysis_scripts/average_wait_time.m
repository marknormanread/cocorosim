%Provide input array and length of simulation run

%Input is an array of the cumulative wait times to send a message
input_array = [4 3 3.5 19.5 6 32 17 3 3 2.5 3 2 25.5 1 11.5 43 1.5 62 34.5 6.5 2 21.5 2.5 2.5 118 1.5 2 24.5 2.5 1 4.5 32.5 7 7.5 58.5 20.5 2 0.5 18.5];
run_duration = 2000;

wait_time_array = [];

for elem=1:length(input_array)
    
    current_wait_time = input_array(elem);
    
    %Expand this wait time into an array of the wait value for each tick
    %and add to overall array
    while current_wait_time > 0
        wait_time_array = [wait_time_array current_wait_time];
        current_wait_time = current_wait_time - 0.5;
    
    end
    
end

%Add zeros for every tick where there was no wait time
total_wait_time_array = padarray(wait_time_array, [0 run_duration - length(wait_time_array)], 'post');
mean_wait_time = mean(total_wait_time_array)
