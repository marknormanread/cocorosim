#=======================================
#
# This file should provide some specifics for the jobs about to be launched on the cluster. 
# It is intended to be called from within the setOff_SGE_generic.rb script.
# The location of this file itself should be provided as a command line argument to that file. 
#
# $paramName - the name of the parameter, as it appears in the netlogo code, and hence directories.
# $paramShort - a short encoding of what the parameter name is, usually just concatenated initials.
# $total_ticks - how many ticks of the simulation are performed before an execution terminates. 
# $numRuns - how many executions are to be performed for each parameter value. 
# $outputSubDir - directory name where output is to be written, eg, output6 or outputGlobal.
# $values - an array of strings, representing the parameter values to be set.
# 
#=======================================

puts "loading experiment specific details"

# Note that these are global variables, directly visible to any script that loads/requires this one.
$paramName = "gps-error"
$paramShort = "GPSE"
$total_ticks = 3600
$numRuns = 500
$outputSubDir = "output"
$values = ['0','5','10','15','20','25','30','35','40','45','50']

